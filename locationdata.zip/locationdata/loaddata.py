import csv
from .models import *
from ulisting.settings import BASE_DIR
import json
def loaddata():
    with open( BASE_DIR / 'locationdata/allCountriesCSV.csv', newline='', encoding="utf8") as csvfile:
        reader = csv.DictReader(csvfile)
        count = 0
        for row in reader:
            if row['COUNTRY'] == 'IN':
                count +=1
                print(count)
                try:
                    pincodeob = Pincode.objects.filter(pin=row['POSTAL_CODE'])
                    if pincodeob.exists():
                        pincodeob = pincodeob[0]
                    else:
                        pincodeob = Pincode(pin=row['POSTAL_CODE'])
                        pincodeob.save()
                    contryob = Country.objects.filter(code = row['COUNTRY'])
                    if contryob.exists():
                        contryob = contryob[0]
                    else:
                        contryob = Country(country=row['COUNTRY'],code=row['COUNTRY'])
                        contryob.save()
                    stateob = State.objects.filter(code = row['SHORT_STATE'])
                    if stateob.exists():
                        stateob = stateob[0]
                    else:
                        stateob = State(country=contryob,code=row['SHORT_STATE'],state=row['STATE'])
                        stateob.save()
                    cityob = City.objects.filter(city=row['COUNTY'])
                    if cityob.exists():
                        cityob = cityob[0]
                    else:
                        cityob = City(state=stateob,city=row['COUNTY'])
                        cityob.save()
                    areaob = Area.objects.filter(area = row['CITY'],pincode = pincodeob.id)
                    if areaob.exists():
                        areaob = areaob[0]
                    else:
                        areaob = Area(city=cityob,pincode=pincodeob,area=row['CITY'])
                        areaob.save()
                    qurdinateob = Qurdinate.objects.filter(latitude=row['LATITUDE'],longitude=row['LONGITUDE'])
                    if qurdinateob.exists():
                        qurdinateob = qurdinateob[0]
                    else:
                        qurdinateob = Qurdinate(area=areaob,latitude=row['LATITUDE'],longitude=row['LONGITUDE'])
                        qurdinateob.save()
                except Exception as e:
                    with open('error.txt',"a",encoding="utf8") as erfile:
                        print(row)
                        print(e)
                        erfile.write(json.dumps(row))