from django.db import models

# Create your models here.
class Country(models.Model):
    country = models.CharField(max_length=100)
    code = models.CharField(max_length=10)
    def __str__(self):
        return self.country
class State(models.Model):
    country = models.ForeignKey(Country,on_delete=models.CASCADE,related_name='Country')
    state = models.CharField(max_length=100)
    code = models.CharField(max_length=10)
    def __str__(self):
        return self.state
class City(models.Model):
    state = models.ForeignKey(State,on_delete=models.CASCADE,related_name='State')
    city = models.CharField(max_length=100)
    def __str__(self):
        return self.city
class Pincode(models.Model):
    pin = models.CharField(max_length=15)
    def __str__(self):
        return self.pin
class Area(models.Model):
    city = models.ForeignKey(City,on_delete=models.CASCADE,related_name='City')
    pincode = models.ForeignKey(Pincode,on_delete=models.CASCADE,related_name='City')
    area = models.CharField(max_length=100)
    def __str__(self):
        return self.area
class Qurdinate(models.Model):
    area = models.ForeignKey(Area,on_delete=models.CASCADE)
    latitude = models.FloatField()
    longitude = models.FloatField()
    def __str__(self):
        return str(self.latitude) + "-" + str(self.longitude)